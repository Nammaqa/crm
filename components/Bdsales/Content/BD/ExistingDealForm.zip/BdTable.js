import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export default function BdTable({ leads = [], onLeadClick, activeTab, onTabChange }) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const filteredLeads = leads.filter((lead) => {
    if (activeTab === "Prospective") {
      return lead.leadType === "prospective" && lead.status === "prospective";
    }
    if (activeTab === "QualifiedLead") {
      return lead.leadType === "new" && lead.status === "newlead";
    }
    if (activeTab === "ExistingDeal") {
      return lead.leadType === "existing" && lead.status === "deal";
    }
    return false;
  });

  // Reset to page 1 when tab changes
  useEffect(() => {
    setCurrentPage(1);
  }, [activeTab]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredLeads.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentLeads = filteredLeads.slice(startIndex, endIndex);

  // Pagination handlers
  const goToPreviousPage = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  };

  const goToNextPage = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  };

  const goToPage = (page) => {
    setCurrentPage(page);
  };

  const tabs = [
    { key: "Prospective", label: "Prospective" },
    { key: "QualifiedLead", label: "Qualified Lead" },
    { key: "ExistingDeal", label: "Existing Deal" },
  ];

  return (
    <div className="mt-8">
      {/* Tabs */}
      <div className="flex gap-2 mb-4 border-b">
        {tabs.map((tab) => (
          <Button
            key={tab.key}
            onClick={() => {
              if (activeTab !== tab.key) onTabChange(tab.key);
            }}
            variant={activeTab === tab.key ? "default" : "ghost"}
            className="py-2 px-6 capitalize rounded-t-lg"
            type="button"
          >
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Table Data */}
      {currentLeads.length > 0 ? (
        <>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-3 text-left">Company</th>
                  <th className="border p-3 text-left">Company ID</th>
                  <th className="border p-3 text-left">Sales Name</th>
                  <th className="border p-3 text-left">Status</th>
                  <th className="border p-3 text-left">Percentage</th>
                </tr>
              </thead>
              <tbody>
                {currentLeads.map((lead) => (
                  <tr
                    key={lead.id}
                    onClick={() => onLeadClick(lead)}
                    className="cursor-pointer hover:bg-gray-50 transition"
                  >
                    <td className="border p-3">{lead.companyName}</td>
                    <td className="border p-3">{lead.companyID || "-"}</td>
                    <td className="border p-3">{lead.salesName}</td>
                    <td className="border p-3 capitalize">{lead.status}</td>
                    <td className="border p-3">{lead.percentage || 0}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-gray-600">
                Showing {startIndex + 1} to {Math.min(endIndex, filteredLeads.length)} of{" "}
                {filteredLeads.length} results
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={goToPreviousPage}
                  disabled={currentPage === 1}
                  variant="outline"
                  size="sm"
                >
                  Previous
                </Button>

                {/* Page Numbers */}
                {[...Array(totalPages)].map((_, index) => {
                  const page = index + 1;
                  return (
                    <Button
                      key={page}
                      onClick={() => goToPage(page)}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      className="w-10 h-10"
                    >
                      {page}
                    </Button>
                  );
                })}

                <Button
                  onClick={goToNextPage}
                  disabled={currentPage === totalPages}
                  variant="outline"
                  size="sm"
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-8 text-gray-500">
          No leads found for this category.
        </div>
      )}
    </div>
  );
}
