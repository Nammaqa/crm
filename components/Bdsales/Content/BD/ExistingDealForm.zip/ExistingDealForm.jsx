"use client";
import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function ExistingDealForm({ formData, setFormData, isEditMode }) {
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!isEditMode) return;
    setSaving(true);

    const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;

    const payload = {
      dealType: formData.dealType,
      employeeName: formData.employeeName || null,
      companySelect: formData.companySelect || null,
      replacementReason: formData.replacementReason || null,
      replacementToDate: formData.replacementToDate || null,
      replacementRequestDate: formData.replacementRequestDate || null,
      remarks: formData.remarks || null,
      spocs: Array.isArray(formData.spocs) ? formData.spocs : [],
    };

    const method = formData.id ? "PUT" : "POST";
    const endpoint = formData.id ? `/api/lead/${formData.id}` : "/api/lead";

    try {
      const res = await fetch(endpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.ok) {
        // update local formData with returned values if provided
        if (data && typeof data === "object") {
          setFormData((prev) => ({ ...prev, ...data }));
        }
        alert("Saved successfully.");
      } else {
        console.error("Save error:", data);
        alert(data?.message || "Failed to save. See console for details.");
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred while saving.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 mb-8 max-w-5xl w-full mx-auto">
      <h2 className="text-2xl font-semibold">Existing Lead Details</h2>

      <div className="bg-white border rounded-lg p-6 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Company Name (Read-only) */}
          <div>
            <Label>Company Name</Label>
            <Input value={formData.companyName} disabled className="bg-gray-50" />
          </div>

          {/* Company ID (Read-only) */}
          <div>
            <Label>Company ID</Label>
            <Input value={formData.companyID} disabled className="bg-gray-50" />
          </div>

          {/* Percentage (Read-only) */}
          <div>
            <Label>Percentage</Label>
            <Input
              value={`${formData.percentage ?? 0}%`}
              disabled
              className="bg-gray-50"
            />
          </div>

          {/* Status */}
          <div>
            <Label>Status</Label>
            <Input
              value={formData.status || "deal"}
              disabled
              className="bg-gray-50 capitalize"
            />
          </div>

          {/* Deal Type */}
          <div className="md:col-span-2">
            <Label>Deal Type</Label>
            <div className="flex items-center gap-6 mt-2">
              {/* "New" option intentionally commented out */}
              {/*
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="new" id="new" disabled={!isEditMode} />
                <Label htmlFor="new">New</Label>
              </div>
              */}
              <RadioGroup
                value={formData.dealType}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, dealType: value }))
                }
                disabled={!isEditMode}
                className="flex items-center gap-6"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem
                    value="replacement"
                    id="replacement"
                    disabled={!isEditMode}
                  />
                  <Label htmlFor="replacement">Replacement</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        </div>

        {/* Replacement fields (shown only when replacement selected) */}
        {formData.dealType === "replacement" && (
          <div className="mt-6 border-t pt-6">
            <h3 className="text-lg font-medium mb-4">Replacement Details</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Employee Name */}
              <div>
                <Label>Employee Name</Label>
                <Input
                  placeholder="Employee Name"
                  value={formData.employeeName || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, employeeName: e.target.value }))
                  }
                  disabled={!isEditMode}
                />
              </div>

              {/* Select Company */}
              <div>
                <Label>Select Company</Label>
                <select
                  value={formData.companySelect || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, companySelect: e.target.value }))
                  }
                  disabled={!isEditMode}
                  className="w-full border rounded px-3 py-2 bg-white"
                  aria-label="Select Company"
                >
                  <option value="" disabled>
                    Select company
                  </option>
                  {formData.companySelect ? (
                    <option value={formData.companySelect}>
                      {formData.companyName || `Company ${formData.companySelect}`}
                    </option>
                  ) : (
                    <option value="">{formData.companyName || "No company available"}</option>
                  )}
                </select>
              </div>

              {/* Select Reason */}
              <div>
                <Label>Select Reason</Label>
                <select
                  value={formData.replacementReason || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, replacementReason: e.target.value }))
                  }
                  disabled={!isEditMode}
                  className="w-full border rounded px-3 py-2 bg-white"
                  aria-label="Select Replacement Reason"
                >
                  <option value="" disabled>
                    Select Reason
                  </option>
                  <option value="resignation">Resignation</option>
                  <option value="termination">Termination</option>
                  <option value="performance">Performance</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Replacement To Date */}
              <div>
                <Label>Replacement To Date</Label>
                <Input
                  type="date"
                  value={formData.replacementToDate || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, replacementToDate: e.target.value }))
                  }
                  disabled={!isEditMode}
                />
              </div>

              {/* Replacement Request Date */}
              <div>
                <Label>Request Date</Label>
                <Input
                  type="date"
                  value={formData.replacementRequestDate || ""}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, replacementRequestDate: e.target.value }))
                  }
                  disabled={!isEditMode}
                />
              </div>
            </div>
          </div>
        )}

        {/* SPOCs (Read-only view) */}
        <div className="mt-6">
          <h3 className="font-semibold mb-3">SPOCs</h3>
          {formData.spocs && formData.spocs.length > 0 ? (
            <div className="space-y-4">
              {formData.spocs.map((spoc, index) => (
                <div
                  key={index}
                  className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded bg-gray-50"
                >
                  <div>
                    <Label className="text-sm">Name</Label>
                    <p className="font-medium">{spoc.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm">Email</Label>
                    <p className="font-medium">{spoc.email}</p>
                  </div>
                  <div>
                    <Label className="text-sm">Contact</Label>
                    <p className="font-medium">{spoc.contact}</p>
                  </div>
                  {spoc.altContact && (
                    <div>
                      <Label className="text-sm">Alt Contact</Label>
                      <p className="font-medium">{spoc.altContact}</p>
                    </div>
                  )}
                  <div>
                    <Label className="text-sm">Designation</Label>
                    <p className="font-medium">{spoc.designation}</p>
                  </div>
                  <div>
                    <Label className="text-sm">Location</Label>
                    <p className="font-medium">{spoc.location}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No SPOCs available</p>
          )}
        </div>

        {/* Remarks (Read-only) */}
        <div className="mt-6">
          <Label>Remarks</Label>
          <div className="p-4 border rounded bg-gray-50 min-h-[100px]">
            {formData.remarks || "No remarks"}
          </div>
        </div>

        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-800 font-semibold">
            ✓ This lead has been moved to Existing Deal (Closed)
          </p>
          <p className="text-sm text-green-700 mt-1">
            This record is now in the final stage and cannot be modified.
          </p>
        </div>

        {isEditMode && (
          <div className="mt-6 flex justify-end">
            <Button onClick={handleSave} disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
