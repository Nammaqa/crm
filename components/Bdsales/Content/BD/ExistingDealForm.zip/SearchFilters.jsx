"use client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  /* Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue, */
} from "@/components/ui/select";
import { Search, X } from "lucide-react";

/* const INDUSTRY_OPTIONS = [
  { value: "it", label: "IT" },
  { value: "finance", label: "Finance" },
  { value: "healthcare", label: "Healthcare" },
  { value: "manufacturing", label: "Manufacturing" },
  { value: "retail", label: "Retail" },
  { value: "education", label: "Education" },
  { value: "telecom", label: "Telecom" },
  { value: "automobile", label: "Automobile" },
  { value: "realestate", label: "Real Estate" },
  { value: "logistics", label: "Logistics" },
  { value: "media", label: "Media" },
  { value: "government", label: "Government" },
  { value: "energy", label: "Energy" },
  { value: "consulting", label: "Consulting" },
  { value: "other", label: "Other" },
]; */

export default function SearchFilters({
  filters,
  onFilterChange,
  onClearFilters,
}) {
  const handleInputChange = (field, value) => {
    onFilterChange({ ...filters, [field]: value });
  };

  const hasActiveFilters = Object.entries(filters).some(
    ([key, val]) => key !== "status" && val !== ""
  );

  return (
    <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Search className="w-5 h-5 text-gray-500" />
          <h3 className="text-lg font-semibold">Search &amp; Filters</h3>
        </div>
        {hasActiveFilters && (
          <Button
            onClick={onClearFilters}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <X className="w-4 h-4" />
            Clear Filters
          </Button>
        )}
      </div>

      {/* Single row with all visible fields except Industry */}
      <div className="flex flex-nowrap items-end gap-4 overflow-x-auto">
        {/* Company Name */}
        <div className="flex flex-col w-[260px] min-w-[260px]">
          <label className="text-sm font-medium mb-1">Company Name</label>
          <Input
            value={filters.companyName}
            onChange={(e) => handleInputChange("companyName", e.target.value)}
            placeholder="Enter company name"
            className="h-10 text-sm"
          />
        </div>

        {/* Sales Owner */}
        <div className="flex flex-col w-[220px] min-w-[220px]">
          <label className="text-sm font-medium mb-1">Sales Owner</label>
          <Input
            value={filters.salesOwner}
            onChange={(e) => handleInputChange("salesOwner", e.target.value)}
            placeholder="Enter sales owner"
            className="h-10 text-sm"
          />
        </div>

        {/* Commented out Industry field */}
        {/*
        <div className="flex flex-col w-[180px] min-w-[180px]">
          <label className="text-sm font-medium mb-1">Industry</label>
          <Select
            value={filters.industry || undefined}
            onValueChange={(value) => handleInputChange("industry", value)}
          >
            <SelectTrigger className="h-10 text-sm" />
            <SelectContent>
              {INDUSTRY_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        */}

        {/* Date From */}
        <div className="flex flex-col w-[180px] min-w-[180px]">
          <label className="text-sm font-medium mb-1">Date From</label>
          <Input
            type="date"
            value={filters.dateFrom}
            onChange={(e) => handleInputChange("dateFrom", e.target.value)}
            className="h-10 text-sm"
          />
        </div>

        {/* Date To */}
        <div className="flex flex-col w-[180px] min-w-[180px]">
          <label className="text-sm font-medium mb-1">Date To</label>
          <Input
            type="date"
            value={filters.dateTo}
            onChange={(e) => handleInputChange("dateTo", e.target.value)}
            className="h-10 text-sm"
          />
        </div>

        {/* Search Icon Button */}
        <div className="flex items-end min-w-[40px]">
          <Button
            size="sm"
            className="h-10 w-10 p-2 bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Active Filters */}
      {hasActiveFilters && (
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="text-sm text-gray-600">Active Filters:</span>
          {filters.companyName && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
              Company: {filters.companyName}
              <X
                className="w-3 h-3 cursor-pointer"
                onClick={() => handleInputChange("companyName", "")}
              />
            </span>
          )}
          {filters.salesOwner && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
              Sales: {filters.salesOwner}
              <X
                className="w-3 h-3 cursor-pointer"
                onClick={() => handleInputChange("salesOwner", "")}
              />
            </span>
          )}
          {filters.dateFrom && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
              From: {filters.dateFrom}
              <X
                className="w-3 h-3 cursor-pointer"
                onClick={() => handleInputChange("dateFrom", "")}
              />
            </span>
          )}
          {filters.dateTo && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
              To: {filters.dateTo}
              <X
                className="w-3 h-3 cursor-pointer"
                onClick={() => handleInputChange("dateTo", "")}
              />
            </span>
          )}
        </div>
      )}
    </div>
  );
}
